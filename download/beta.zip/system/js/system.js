    command("demo","width","1920px");
    command("demo","height","1080px");
    command("demo","backgroundImage","url(system/img/backgroundImage.png)");
    command("icon","帮助","system/img/icon.png",'command("open","help")');